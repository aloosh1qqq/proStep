class AppStrings {
  static const noRouteFound = "No Route Found";
  static const onboardingtitle1 = "Grow with ";
  static const onboardingtitle2 = "Empower youreducation to next level";
  static const onboardingtitle3 =
      "Improve your skills from now with an expert mentor!";

 static const onboardingsubtitle1 = "ProStep!";
  static const onboardingsubtitle2 =
      "Learn new things and develop your problem solving skills ";
  static const onboardingsubtitle3 =
      "Learn new things and develop your problem solving skills ";
  static const skip = "Skip";
  static const next = "Next";
}
