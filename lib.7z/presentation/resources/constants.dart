class AppConstants {
  //static const int splashdelay = 5;
  static const int sliderAnimationTime = 1;
}
